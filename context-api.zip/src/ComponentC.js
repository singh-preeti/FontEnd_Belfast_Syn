import React from 'react';
import ComponentD from './ComponentD';

class ComponentC extends React.Component{
    render()
    {
        return(
            <div>
                <ComponentD />
            </div>
        )
    }
}
export default ComponentC;