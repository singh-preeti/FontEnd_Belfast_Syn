import React from 'react';
import ComponentE from './ComponentE';

class ComponentD extends React.Component{
    render()
    {
        return(
            <div>
                <ComponentE />
            </div>
        )
    }
}
export default ComponentD;