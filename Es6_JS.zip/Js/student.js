console.log('object-create-students-and-address-object');

const Students = {
  name: 'Preety',
  age: 35,
  rank: 5,
  country: 'India',
}

const Address = {
  street: 'Lokhandwala',
  city: 'Mumbai',
  pinCode: 400101,
  state: 'MH',
  country: 'India',
}

function showObjectDetails(obj) {
  for(let key in obj) {
    console.log(key,' : ',obj[key]);
  }
}

showObjectDetails(Students);
console.log('----------');
showObjectDetails(Address);