function showStar(totalPatternCount){
    for(let curRow = 1; curRow <= totalPatternCount; curRow++){
        let patternDesign = '';
        for(let i = 0; i< curRow; i++){
            patternDesign += '*'
        }
        document.write(patternDesign);
        console.log(patternDesign);
    }
}
showStar(5);