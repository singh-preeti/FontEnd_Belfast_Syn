function findMaxNumber(num1,num2){
    //1. Long syntax
    // if(num1>num2){
    //     return num1
    // }
    // else
    // {
    //     return num2
    // }
  //2. Short syntax
    // if(num1 >num2) return num1;
    // else return num2;
  //3. Ternary operator
  return (num1 > num2)?num1 : num2;

}
let checkmax1 = findMaxNumber(10,20);
document.write(checkmax1);