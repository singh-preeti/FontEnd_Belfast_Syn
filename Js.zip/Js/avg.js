const MarksArray = [65, 85, 75,45];

function calculateAverageGrade(currentMarks){
    let totalMarks = 0;
    let averageMarks = 0;
    let grade;

    for(let mark of currentMarks){
        totalMarks += mark;}

        console.log(totalMarks);

        averageMarks = (totalMarks/currentMarks.length);

        console.log(averageMarks);

        if(averageMarks <70) return grade = "D";
        if(averageMarks<80) return grade = "C";
        if(averageMarks<90) return grade = "B";
        if(averageMarks<=100) return grade = "A";
    }
console.log("Grade:" , calculateAverageGrade(MarksArray));