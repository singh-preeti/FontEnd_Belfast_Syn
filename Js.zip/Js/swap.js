console.log("Swapping the variables value");

let value1 = "One";
let value2 = "Two";

//original value
console.log("Original" , value1);
console.log("Oroginal", value2);

document.write("Original" , value1);
document.write("Oroginal", value2);
//swapping values
let value3 = value1;
value1 = value2;
value2 = value3;

console.log("Swap" , value1);
console.log("Swap", value2);
document.write("Swap" , value1);
document.write("Swap", value2);

