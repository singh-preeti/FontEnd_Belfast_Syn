
import React, {useState, useReducer, useEffect} from 'react';
import axios from 'axios';
const  App = () => {

  const [data, setData] = useState("");

  useEffect(() => {
  axios
     .get("https://jsonplaceholder.typicode.com/comments")
     .then((response) => {
      setData(response.data[0].name);
      console.log("Api was called" +response);
     });
    });
    return <div>{data}</div>;
    
 

//   const reducer  = (initState, action) => {
//     switch (action.type) {
//       case "INCREMENT": 
//         return {count: initState.count+1 , showText: initState.showText}
//       case "toggleText":
//         return {count: initState.count , showText: !initState.showText}
//       default : 
//       return initState
//     }
//   }
//  const [state, dispatch] = useReducer(reducer , {count : 0 ,showText: true})
  
//  return(
//     <div className="App">
//      <h1>{state.count}</h1>
//      <button onClick={() => {
//          dispatch({
//           type: "INCREMENT"
//          });
//         // setShowText(!showText);
//      }}>Click here</button>
     
//      {state.showText && <p>This is react hooks session</p>}
//     </div>
//   )
//  const [counter, setCounter] = useState(0);
  
//  const increment = () => {
//     setCounter(counter + 1);
//     console.log(counter);
//   };
//   return (
//     <div className="App">
//       {counter}
//       <button onClick={increment}>Increment</button>
//     </div>
//   );

// const [inputValue, setInputeValue] = useState("Jesicca");

// let onChange = (event) => {
//   const newValue = event.target.value;
//   setInputeValue(newValue);
// }
// return(
//   <div className="App">
//      <input placeholder='enter the name' onChange={onChange} />
//      {inputValue}
//   </div>
//)
}

export default App;
